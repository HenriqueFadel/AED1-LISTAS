#include <stdio.h>
#include <stdbool.h>

#define MAX_SIZE 10

void readMatrix(int matrix[MAX_SIZE][MAX_SIZE], int rows, int cols) {
    printf("Digite os elementos da matriz:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void findLargestElement(int matrix[MAX_SIZE][MAX_SIZE], int rows, int cols) {
    int maxElement = matrix[0][0];
    int maxRow = 0;
    int maxCol = 0;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (matrix[i][j] > maxElement) {
                maxElement = matrix[i][j];
                maxRow = i;
                maxCol = j;
            }
        }
    }

    printf("O maior elemento da matriz � %d e sua posi��o � (%d, %d).\n", maxElement, maxRow, maxCol);
}

void sumDiagonal(int matrix[MAX_SIZE][MAX_SIZE], int size) {
    int diagonalSum = 0;

    for (int i = 0; i < size; i++) {
        diagonalSum += matrix[i][i];
    }

    printf("A soma dos elementos da diagonal principal � %d.\n", diagonalSum);
}

void extractDiagonal(int matrix[MAX_SIZE][MAX_SIZE], int size, int diagonal[MAX_SIZE]) {
    for (int i = 0; i < size; i++) {
        diagonal[i] = matrix[i][i];
    }
}

void sumMatrices(int matrixA[MAX_SIZE][MAX_SIZE], int matrixB[MAX_SIZE][MAX_SIZE], int rows, int cols, int result[MAX_SIZE][MAX_SIZE]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result[i][j] = matrixA[i][j] + matrixB[i][j];
        }
    }
}

void multiplyMatrices(int matrixA[MAX_SIZE][MAX_SIZE], int rowsA, int colsA, int matrixB[MAX_SIZE][MAX_SIZE], int rowsB, int colsB, int result[MAX_SIZE][MAX_SIZE]) {
    if (colsA != rowsB) {
        printf("O n�mero de colunas da matriz A n�o � igual ao n�mero de linhas da matriz B.\n");
        return;
    }

    for (int i = 0; i < rowsA; i++) {
        for (int j = 0; j < colsB; j++) {
            result[i][j] = 0;
            for (int k = 0; k < colsA; k++) {
                result[i][j] += matrixA[i][k] * matrixB[k][j];
            }
        }
    }
}

bool isPermutationMatrix(int matrix[MAX_SIZE][MAX_SIZE], int size) {
    int rowSum, colSum;

    for (int i = 0; i < size; i++) {
        rowSum = 0;
        colSum = 0;

        for (int j = 0; j < size; j++) {
            rowSum += matrix[i][j];
            colSum += matrix[j][i];

            if (matrix[i][j] != 0 && matrix[i][j] != 1) {
                return false;
            }
        }

               if (rowSum != 1 || colSum != 1) {
            return false;
        }
    }

    return true;
}

bool isMagicSquare(int matrix[MAX_SIZE][MAX_SIZE], int size) {
    int rowSum, colSum, mainDiagonalSum, secondaryDiagonalSum;
    int targetSum;

    // Calculating the target sum (sum of rows, cols, and diagonals)
    targetSum = 0;
    for (int i = 0; i < size; i++) {
        targetSum += matrix[0][i];
    }

    // Checking row sums
    for (int i = 0; i < size; i++) {
        rowSum = 0;
        for (int j = 0; j < size; j++) {
            rowSum += matrix[i][j];
        }
        if (rowSum != targetSum) {
            return false;
        }
    }

    // Checking column sums
    for (int j = 0; j < size; j++) {
        colSum = 0;
        for (int i = 0; i < size; i++) {
            colSum += matrix[i][j];
        }
        if (colSum != targetSum) {
            return false;
        }
    }

    // Checking main diagonal sum
    mainDiagonalSum = 0;
    for (int i = 0; i < size; i++) {
        mainDiagonalSum += matrix[i][i];
    }
    if (mainDiagonalSum != targetSum) {
        return false;
    }

    // Checking secondary diagonal sum
    secondaryDiagonalSum = 0;
    for (int i = 0; i < size; i++) {
        secondaryDiagonalSum += matrix[i][size - i - 1];
    }
    if (secondaryDiagonalSum != targetSum) {
        return false;
    }

    return true;
}

void swapRows(int matrix[MAX_SIZE][MAX_SIZE], int row1, int row2, int cols) {
    int temp;
    for (int j = 0; j < cols; j++) {
        temp = matrix[row1][j];
        matrix[row1][j] = matrix[row2][j];
        matrix[row2][j] = temp;
    }
}

void swapColumns(int matrix[MAX_SIZE][MAX_SIZE], int rows, int col1, int col2) {
    int temp;
    for (int i = 0; i < rows; i++) {
        temp = matrix[i][col1];
        matrix[i][col1] = matrix[i][col2];
        matrix[i][col2] = temp;
    }
}

void swapDiagonals(int matrix[MAX_SIZE][MAX_SIZE], int size) {
    int temp;
    for (int i = 0; i < size; i++) {
        temp = matrix[i][i];
        matrix[i][i] = matrix[i][size - i - 1];
        matrix[i][size - i - 1] = temp;
    }
}

void swapRowWithColumn(int matrix[MAX_SIZE][MAX_SIZE], int rows, int cols, int row, int col) {
    int temp;
    for (int i = 0; i < rows; i++) {
        temp = matrix[i][col];
        matrix[i][col] = matrix[row][i];
        matrix[row][i] = temp;
    }
}
void printMatrix(int matrix[MAX_SIZE][MAX_SIZE], int rows, int cols) {
    printf("Matriz resultante:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}


int main() {
    int option;
    int matrix[MAX_SIZE][MAX_SIZE];
    int size;
    int diagonal[MAX_SIZE];
    int cols;

    do {
        printf("\nMENU\n");
        printf("1. Ler matriz e encontrar o maior elemento e sua posicao\n");
        printf("2. Calcular soma dos elementos da diagonal principal e extrair a diagonal\n");
        printf("3. Calcular a matriz resultante da soma de duas matrizes\n");
        printf("4. Calcular a matriz resultante do produto de duas matrizes\n");
        printf("5. Verificar se uma matriz eh uma matriz de permuta��o\n");
        printf("6. Verificar se uma matriz eh um quadrado m�gico\n");
        printf("7. Realizar alteracoes na matriz Z\n");
        printf("0. Sair\n");

        printf("Escolha uma opcao: ");
        scanf("%d", &option);

        switch (option) {
            case 1:
                printf("Digite o n�mero de linhas da matriz: ");
                scanf("%d", &size);
                readMatrix(matrix, size, size);
                findLargestElement(matrix, size, size);
                break;

            case 2:
    printf("Digite a dimensao da matriz quadrada: ");
    scanf("%d", &size);
    readMatrix(matrix, size, size);
    sumDiagonal(matrix, size);
    extractDiagonal(matrix, size, diagonal);
    printf("Diagonal principal: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", diagonal[i]);
    }
    printf("\n");
    break;


     case 3:
    printf("Digite o n�mero de linhas da matriz A: ");
    scanf("%d", &size);
    readMatrix(matrix, size, size);
    printf("Digite o n�mero de colunas da matriz B: ");
    scanf("%d", &cols);
    readMatrix(matrix, size, cols);
    if (size > MAX_SIZE || cols > MAX_SIZE) {
        printf("Dimens�es da matriz excedem o tamanho m�ximo permitido.\n");
        break;
    }
    sumMatrices(matrix, matrix, size, cols, matrix);
    printMatrix(matrix, size, cols);
    break;



            case 4:
                printf("Digite o n�mero de linhas da matriz A: ");
                scanf("%d", &size);
                readMatrix(matrix, size, size);
                printf("Digite o n�mero de colunas da matriz B: ");
                scanf("%d", &size);
                readMatrix(matrix, size, size);
                if (size > MAX_SIZE) {
                    printf("Dimens�es da matriz excedem o tamanho m�ximo permitido.\n");
                    break;
                }
                multiplyMatrices(matrix, size, size, matrix, size, size, matrix);
                printMatrix(matrix, size, size);
                break;

            case 5:
                printf("Digite a dimens�o da matriz quadrada: ");
                scanf("%d", &size);
                readMatrix(matrix, size, size);
                if (isPermutationMatrix(matrix, size)) {
                    printf("A matriz � uma matriz de permuta��o.\n");
                } else {
                    printf("A matriz n�o � uma matriz de permuta��o.\n");
                }
                break;

            case 6:
                printf("Digite a dimens�o case 6:");
                printf("Digite a dimens�o da matriz quadrada: ");
                scanf("%d", &size);
                readMatrix(matrix, size, size);
                if (isMagicSquare(matrix, size)) {
                    printf("A matriz � um quadrado m�gico.\n");
                } else {
                    printf("A matriz n�o � um quadrado m�gico.\n");
                }
                break;

            case 7:
                printf("Digite o n�mero de linhas da matriz Z: ");
                scanf("%d", &size);
                readMatrix(matrix, size, size);
                swapRows(matrix, 1, 7, size);
                swapColumns(matrix, size, 3, 9);
                swapDiagonals(matrix, size);
                swapRowWithColumn(matrix, size, size, 4, 9);
                printMatrix(matrix, size, size);
                break;

            case 0:
                printf("Encerrando o programa...\n");
                break;

            default:
                printf("Op�ao invalida! Tente novamente.\n");
                break;
        }
    } while (option != 0);

    return 0;
}






