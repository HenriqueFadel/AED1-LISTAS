#include <stdio.h>

int main() {
    int n;
    float so = 0;
    printf("escreva um valor para n: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        so += (float) i / (n - i + 1);
    }
    printf(" somat�rio �: %f\n", so);
    return 0;
}

