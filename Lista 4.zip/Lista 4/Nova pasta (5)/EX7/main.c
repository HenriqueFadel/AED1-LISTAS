#include <stdio.h>

int main() {
    int m, n, i, j;
    printf("Escreva um valor:");
    scanf("%d", &m);
    while (m < 1) {
        printf("ERRO.INVALIDO");
        scanf("%d", &m);
    }
    printf("Escreva um valor ate 10: ");
    scanf("%d", &n);
    while (n < 1 || n > 10) {
        printf("ERRO.INVALIDO");
        scanf("%d", &n);
    }
    printf("x\t");
    for (i = 1; i <= n; i++) {
        printf("x%d\t", i);
    }
    printf("\n");
    for (i = 1; i <= m; i++) {
        if (i < 10) {
            printf("%d\t", i);
        } else {
            printf("%d\t", i);
        }
        for (j = 1; j <= n; j++) {
            if (j == 1) {
                printf("%d\t", i * j);
            } else {
                printf("%d\t", i * j + j - 1);
            }
        }
        printf("\n");
    }
    return 0;
}
