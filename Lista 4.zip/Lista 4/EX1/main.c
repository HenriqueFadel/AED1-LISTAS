#include <stdio.h>

int main() {
    int n;
    float Soma = 0;

    printf("escreva um numero positivo:");
    scanf("%d", &n);

    for(int i = 1; i <= n; i++) {
        Soma += 1.0/i;
        printf("Termo %d: %f\n", i, 1.0/i);
    }

    printf("Soma final: %f", Soma);

    return 0;
}
