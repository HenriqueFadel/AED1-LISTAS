#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
int d_m(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) + abs(y1 - y2);
}

int n_a(int min, int max) {
    return rand() % (max - min + 1) + min;
}

int main() {
    int x_p, y_p;
    printf("coordenadas para o ponto P:\n");
    printf("x = ");
    scanf("%d", &x_p);
    printf("y = ");
    scanf("%d", &y_p);
   int n;
    printf("escreva o numero de pontos para serem gerados: ");
    scanf("%d", &n);


    srand(time(NULL));
    int s_d = 0;
    for (int i = 1; i <= n; i++) {
        int x_i = n_a(1, 10);
        int y_i = n_a(1, 10);


        int dist = d_m(x_p, y_p, x_i, y_i);

     s_d += dist;
    }


    printf("soma de P para os %d pontos ser�: %d\n", n, s_d);

    return 0;
}
