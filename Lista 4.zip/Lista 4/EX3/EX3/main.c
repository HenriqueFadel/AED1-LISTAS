#include <stdio.h>
#include <math.h>

int main() {
    int n, k;
    printf("numero: ");
    scanf("%d", &n);
    printf("valor de k: ");
    scanf("%d", &k);
    int num_digitos = (int) log10(n) + 1;
    if (k <= num_digitos) {
        int resto = n % (int) pow(10, k);
        int k_esimo_digito = resto / (int) pow(10, k - 1);
        printf("%d� d�gito de %d �: %d\n", k, n, k_esimo_digito);
    } else {
        printf("O n�mero %d tem %d d�gitos, IMPOSSIVEL encontrar o %d� d�gito.", n, num_digitos, k);
    }
    return 0;
}
