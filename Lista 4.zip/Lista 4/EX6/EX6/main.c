#include <stdio.h>

int main() {
    int x;
    printf("x\t x1\t x2\t x3\t x4\n");
    for (x = 1; x <= 100; x++) {
        printf("%d\t %d\t %d\t %d\t %d\n", x, x * x, x * x * x, 2 * x, 3 * x);
    }
    return 0;
}
