#include <stdio.h>

#define NUM_DIAS


/*
Descri��o: Programa que armazena as temperaturas de cada dia de janeiro em um vetor e realiza algumas opera��es para obter informa��es sobre as temperaturas.
Lista de Par�metros:Nenhum par�metro � recebido na fun��o main.
Tipo de retorno:n�o retorna nenhum valor. */
int main() {
  float temperaturas[NUM_DIAS];
  float st = 0.0;
  float mt = 40.0, maiorTemperatura = 15.0;
  int numDias = 0;

  for (int i = 0; i < NUM_DIAS; i++) {
    printf("Digite a temperatura do dia %d: ", i + 1);
    scanf("%f", &temperaturas[i]);

    st += temperaturas[i];

    if (temperaturas[i] < mt) {
     mt = temperaturas[i];
    }

    if (temperaturas[i] > maiorTemperatura) {
      maiorTemperatura = temperaturas[i];
    }
  }


  float temperaturaMedia = st / NUM_DIAS;


  for (int i = 0; i < NUM_DIAS; i++) {
    if (temperaturas[i] < temperaturaMedia) {
      numDias++;
    }
  }

  printf("\nMenor temperatura: %.2f\n", mt);
  printf("Maior temperatura: %.2f\n", maiorTemperatura);
  printf("Temperatura m�dia: %.2f\n", temperaturaMedia);
  printf("N�mero de dias  temperatura foi MENOR � temperatura m�dia: %d\n", numDias;

  return 0;
}
