#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*
Descri��o: recebe uma string e um caractere e retorna o n�mero de ocorr�ncia
Lista de Par�metros:
    - str: ponteiro para char
    - ch: char
Tipo de retorno: int, n�mero total
*/
int cC(char* str, char c) {
    int count = 0;
    int i;
    for(i = 0; str[i] != '\0'; i++) {
        if(tl(str[i]) == tl(c)) {
            count++;
        }
    }
    return count;
}

int main() {
    char str[100];
    char c;
    printf("escreva uma string: ");
    scanf("%[^\n]", str);
    printf("ESCREVA um caractere PF: ");
    scanf(" %c", &c);
    printf(" %c aparece %d vezes .\n", c, cC(str, c));
    return 0;
}

