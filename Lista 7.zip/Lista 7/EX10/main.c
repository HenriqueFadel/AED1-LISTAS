#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*
Descri��o: remove sequ�ncias de espa�os cont�nuos
Lista de Par�metros:

str: string que representa a frase a ser analisada
Tipo de retorno: a fun��o retorna uma nova string
*/
void r_e(char *frase) {
    int i, j, tam = strlen(frase);
    int flag = 0;
        for (i = 0, j = 0; i < tam; i++) {

        if (isspace(frase[i])) {

            if (!flag) {
                frase[j++] = frase[i];
                flag = 1;
            }
        }

        else {
            frase[j++] = frase[i];
            flag = 0;
        }
    }

    frase[j] = '\0';
}

int main() {
    char frase[100];

    printf("ESCREVA UMA FRASE: ");
    fgets(frase, 100, stdin);

    r_e(frase);

    printf("Frase REFEITA: %s\n", frase);

    return 0;
}
