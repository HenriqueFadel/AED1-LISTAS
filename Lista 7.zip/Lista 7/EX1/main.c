#include <stdio.h>
#include <ctype.h>
/*
Descri��o: conta o n�mero de caracteres alfanum�ricos em uma string
Lista de Par�metros:
- str: string
Tipo de retorno: n�mero de caracteres alfanum�ricos
*/
int alphanum(char *str) {
    int count = 0;
    while (*str != '\0') {
        if (isalnum(*str)) {
            count++;
        }
        str++;
    }
    return count;
}

int main() {
    char str[100];
    printf("ESCREVA uma string: ");
    scanf("%s", str);
    int count = alphanum(str);
    printf("A string possui %d caracteres alfanum�ricos.\n", count);
    return 0;
}
