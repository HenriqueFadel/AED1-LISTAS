#include <stdio.h>


/*
Descri��o:  preencher dois vetores X e Y com 10 elementos cada

Lista de Par�metros: n�o possui par�metros e n�o retorna nenhum valor.

Tipo de retorno:n�o possuem retorno
*/
void p_v(int x[], int y[]) {
    int i;
    printf("PreeNCHER  o vetor X:\n");
    for (i = 0; i < 10; i++) {
        printf("ESCREVA O VALOR DE %d: ", i);
        scanf("%d", &x[i]);
    }
    printf("\nPREENCHER o vetor Y:\n");
    for (i = 0; i < 10; i++) {
        printf("ESCREVA O VALOR DE %d: ", i);
        scanf("%d", &y[i]);
    }
}

void i_v(int x[], int y[], int z[]) {
    int i, j;
    for (i = 0, j = 0; i < 10; i++, j += 2) {
        z[j] = x[i];
        z[j+1] = y[i];
    }
}

void e_v(int z[]) {
    int i;
    printf("\nConteudo do vetor:\n");
    for (i = 0; i < 20; i++) {
        printf("%d ", z[i]);
    }
    printf("\n");
}

int main() {
    int x[10], y[10], z[20];
    p_v(x, y);
    i_v(x, y, z);
    e_v(z);
    return 0;
}
