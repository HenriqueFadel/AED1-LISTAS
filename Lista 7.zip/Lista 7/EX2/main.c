#include <stdio.h>

/*
Descri��o:  preenche um vetor com as notas de uma turma e  calcula a m�dia da turma e conta quantos alunosreceberam nota acima da m�dia
Lista de Par�metros:
- notas: vetor
Tipo de retorno: procedimento (void)
*/
void preencher(float notas[]) {
    printf("Digite 10 notas:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%f", &notas[i]);
    }
}

void mediaa(float notas[]) {
    float media = 0;
    for (int i = 0; i < 10; i++) {
        media += notas[i];
    }
    media /= 10;

    int count_acima = 0;
    for (int i = 0; i < 10; i++) {
        if (notas[i] > media) {
            count_acima++;
        }
    }

    printf("A m�dia � %.2f.\n", media);
    printf("%d alunos recebram nota acima da m�dia.\n", count_acima);
}

int main() {
    float notas[10];
    preencher(notas);
    mediaa(notas);
    return 0;
}
