#include <stdio.h>
#include <string.h>

/*
Descri��o: ler uma quantidade  de nomes at�a palavra "stop" e exibir o primeiro e �ltimo nome
Lista de Par�metros:
Tipo de retorno: void
*/
void pri_ul() {
    char nome[50], pri[50], ul[50];

    printf("ESCREVA NOMES PF: \n");
    while(1) {
        scanf("%s", nome);
        if(strcmp(nome, "stop") == 0) {
            break;
        }
        if(strlen(pri) == 0 || strcmp(nome, pri) < 0) {
            strcpy(pri, nome);
        }
        if(strlen(ul) == 0 || strcmp(nome, ul) > 0) {
            strcpy(ul, nome);
        }
    }

    printf("Primeiro nome : %s\n", pri);
    printf("�ltimo nome : %s\n", ul);
}

int main() {
    pri_ul();
    return 0;
}
