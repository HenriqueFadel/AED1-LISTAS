#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*
Descri��o: Fun��o que recebe uma string e um vetor de inteiros com tamanho 5 e preenche o vetor
com o n�mero de ocorr�ncias de cada vogal na string
Lista de Par�metros:

str: string a ser verificada
vogais: vetor de inteiros com tamanho 5 para armazenar o n�mero de ocorr�ncias de cada vogal,
sendo que cada posi��o representa uma vogal: vogais[0] = "a", vogais[1] = "e", vogais[2] = "i",
vogais[3] = "o" e vogais[4] = "u".
Tipo de retorno: void
*/
void cv(char *str, int *vogais) {
    int i, len;
    char c;

    len = strlen(str);
    for (i = 0; i < len; i++) {
        c = tolower(str[i]);
        if (c == 'a') {
            vogais[0]++;
        } else if (c == 'e') {
            vogais[1]++;
        } else if (c == 'i') {
            vogais[2]++;
        } else if (c == 'o') {
            vogais[3]++;
        } else if (c == 'u') {
            vogais[4]++;
        }
    }
}

int main() {
    char str[100];
    int vogais[5] = {0, 0, 0, 0, 0};

    printf("Digite uma string: ");
    scanf("%[^\n]", str);

    cv(str, vogais);

    printf("Numero de  'a': %d\n", vogais[0]);
    printf("Numero de  'e': %d\n", vogais[1]);
    printf("Numero de  'i': %d\n", vogais[2]);
    printf("Numero de  'o': %d\n", vogais[3]);
    printf("Numero de  'u': %d\n", vogais[4]);

    return 0;
}
