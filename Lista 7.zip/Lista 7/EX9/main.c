#include <stdio.h>
#include <string.h>

/*
Descri��o:  concatenar tr�s strings e exibir o resultado.
Lista de Par�metros: t�s string a ser concatenadas

Tipo de retorno: procedimento
*/
void cS(char str1[], char str2[], char str3[]) {
    strcat(str1, str2);
    strcat(str1, str3);
    printf("%s\n", str1);
}

int main() {
    char str1[100], str2[100], str3[100];

    printf("ESCREVA PRIMEIRA STRING PF: ");
    fgets(str1, sizeof(str1), stdin);
    str1[strcspn(str1, "\n")] = '\0';

    printf("ESCREVA A SEGUNDA STRING: ");
    fgets(str2, sizeof(str2), stdin);
    str2[strcspn(str2, "\n")] = '\0';

    printf("ESCREVA A TERCEIRA STRING: ");
    fgets(str3, sizeof(str3), stdin);
    str3[strcspn(str3, "\n")] = '\0';
    cS(str1, str2, str3);

    return 0;
}
