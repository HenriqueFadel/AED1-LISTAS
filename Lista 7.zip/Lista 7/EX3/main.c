#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*
Descri��o:  recebe duas frases como par�metro e retorna as letras mai�sculas
Lista de Par�metros:
- frase1: primeira frase
- frase2: segunda
Tipo de retorno: procedimento (void)
*/

void converter(char frase1[], char frase2[]) {
    for (int i = 0; i < strlen(frase1); i++) {
        frase1[i] = toupper(frase1[i]);
    }
    for (int i = 0; i < strlen(frase2); i++) {
        frase2[i] = toupper(frase2[i]);
    }
}

int main() {
    char frase1[100], frase2[100];

    printf("a primeira frase: ");
    fgets(frase1, 100, stdin);

    printf("segunda frase: ");
    fgets(frase2, 100, stdin);

    converter(frase1, frase2);

    printf("Frase 1 : %s", frase1);
    printf("Frase 2 : %s", frase2);

    return 0;
}

