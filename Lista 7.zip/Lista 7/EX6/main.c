#include <stdio.h>
#include <stdlib.h>

/*
Descri��o:  preencher um vetor X de 10 elementos
Lista de Par�metros: vetor de inteiros
Tipo de retorno: void

Descri��o:  copiar valores negativos de um vetor
Lista de Par�metros: vetor de inteiros , tamanho do vetor , vetor resultado
Tipo de retorno: vetor de inteiros

Descri��o: MOSTRAR o conte�do de um vetor
Lista de Par�metros: vetor de inteiros
Tipo de retorno: void
*/


void p_v(int x[], int tam) {
    printf("Digite %d valores:\n", tam);
    for (int i = 0; i < tam; i++) {
        scanf("%d", &x[i]);
    }
}

int* c_n(int x[], int tam, int *tam_novovetor) {
    int *nV = malloc(sizeof(int) * tam);
    int j = 0;
    for (int i = 0; i < tam; i++) {
        if (x[i] < 0) {
            nV[j] = x[i];
            j++;
        }
    }
    *tam_novovetor = j;
    return nV;
}

void e_v(int x[], int tam) {
    printf("Conte�do do vetor:\n");
    for (int i = 0; i < tam; i++) {
        printf("%d ", x[i]);
    }
    printf("\n");
}

int main() {
    int v[10];
    p_v(v, 10);
    int tam_novovetor;
    int *nV = c_n(v, 10, &tam_novovetor);
    printf("novo vetor:\n");
    e_v(nV, tam_novovetor);
    free(nV);
    return 0;
}





