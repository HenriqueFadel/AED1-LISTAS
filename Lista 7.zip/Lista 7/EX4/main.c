#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>

/*
Descri��o: recebe a placa do ve�culo como par�metro e verifica a placa.
Lista de Par�metros:
- placa: a placa do ve�culo
Tipo de retorno: booleano
*/

bool validar(char pla[]) {
    int tamanho = strlen(pla);

    if (tamanho != 7) {
        return false;
    }

    for (int i = 0; i < tamanho; i++) {
        if (i < 3) {
            if (!isalpha(pla[i]) || !isupper(pla[i])) {
                return false;
            }
        } else if (i == 3) {
            if (!isdigit(pla[i])) {
                return false;
            }
        } else if (i > 3) {
            if (!isdigit(pla[i])) {
                return false;
            }
        }
    }

    return true;
}

int main() {
    char pla[8];

    while (true) {
        printf("ESCREVA UMA PLACA PF: ");
        scanf("%s", pla);

        if (strcmp(pla, "fechar") == 0) {
            break;
        }

        if (validar(pla)) {
            printf("correta.\n");
        } else {
            printf("incorreta.\n");
        }
    }

    return 0;
}

