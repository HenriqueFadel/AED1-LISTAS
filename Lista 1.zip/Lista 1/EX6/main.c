#include <stdio.h>
#include <stdlib.h>

int main()
{
    float altura, peso;
    printf(" escreva altura:");
    scanf("%f",&altura);
    printf("escreva o peso:");
    scanf("%f",&peso);
    float imc;
    imc= peso/(altura*altura);
    printf("o seu imc ser�:%f",imc);
    return 0;
}
