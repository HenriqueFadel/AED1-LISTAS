#include <stdio.h>
#include <stdlib.h>

int main()
{
    float farenheit,Celsius;
    printf("escreva valor de farenheit:");
    scanf("%f",&farenheit);
    Celsius = 5.0 / 9.0 * (farenheit - 32);
    printf(" a temperatura em %ffarenheit convertida para %fCelcius ser�:",Celsius);
    return 0;
}
