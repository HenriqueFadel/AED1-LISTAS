#include <stdio.h>
#include <stdlib.h>

int main()
{
    float n1,n2,n3;
    printf("escreva o valor de n1:");
    scanf("%f",&n1);
    printf("escreva o valor de n2:");
    scanf("%f",&n2);
    printf("escreva o valor de n3:");
    scanf("%f",&n3);
     float soma, media, produto;
     soma= n1+n2+n3;
     media= n1+n2+n3/3;
     produto= n1*n2*n3;
     printf("o resultado da soma �: %f", soma);
     printf("o resultado da media �: %f", media);
     printf("o resultado do produto � �: %f", produto);



    return 0;
}
