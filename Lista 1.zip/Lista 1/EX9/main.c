#include <stdio.h>
#include <stdlib.h>

int main()
{
    float meses,valor_investido,juros,juros_rendidos,valor_total;
    printf("digite o valor investido:$");
    scanf("%f",&valor_investido);
    printf("digite o numero de meses:");
    scanf("%f",&meses);
    printf("digite o valor do juros:");
    scanf("%f",&juros);
    juros_rendidos = valor_investido * juros * meses;
    valor_total = juros_rendidos + valor_investido;
    printf("o valor de juros rendidos ser�: %f", juros_rendidos);
    printf("o valor total ser�: %f",valor_total);



    return 0;
}
