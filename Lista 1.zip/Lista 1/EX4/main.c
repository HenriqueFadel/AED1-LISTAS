#include <stdio.h>
#include <stdlib.h>

int main()
{
   int n;
    printf("escreva um n�mero inteiro:");
    scanf("%D",&n);
    printf("o proximo n�mero de %d ser�: %d",n, n+1);


    return 0;
}
