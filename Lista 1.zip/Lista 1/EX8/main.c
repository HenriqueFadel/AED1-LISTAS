#include <stdio.h>
#include <stdlib.h>

int main()
{
    float horas_trabalhadas,salario_minimo,salario_bruto, salario_liquido, valor_hora_trabalhada,imposto;
    printf("escreva o numero de horas trabalhadas:");
    scanf("%f",&horas_trabalhadas);
    printf("escreva o valor do salario minimo:");
    scanf("%f",&salario_minimo);
    valor_hora_trabalhada= salario_minimo * 0.1;
    salario_bruto = horas_trabalhadas * valor_hora_trabalhada;
    imposto = salario_bruto * 0.05;
    salario_liquido = salario_bruto-imposto;
    printf("Valor da hora trabalhada:%f", valor_hora_trabalhada);
    printf("Sal�rio bruto:%f", salario_bruto);
    printf("Imposto:%f", imposto);
    printf("Sal�rio l�quido:%f", salario_liquido);
return 0;
}
