#include <stdio.h>

int main() {
  int valor,positivos = 0, negativos = 0, zeros = 0, total_valores = 0;
  float perc_positivos, perc_negativos, perc_zeros;

  printf("escreva uma sequencia de valores:);

  while (1) {
    scanf("%d", &valor);

    if (valor == -9999) {
      break;
    }

    if (valor > 0) {
      positivos++;
    } else if (valor < 0) {
      negativos++;
    } else {
      zeros++;
    }

    total_valores++;
  }

  perc_positivos = positivos / total_valores * 100;
  perc_negativos = negativos / total_valores * 100;
  perc_zeros = (zeros / total_valores * 100;

  printf("Total de valores fornecidos: %d\n", total_valores);
  printf("Valores positivos: %d (%.2f%%)\n", positivos, perc_positivos);
  printf("Valores negativos: %d (%.2f%%)\n", negativos, perc_negativos);
  printf("Valores zeros: %d (%.2f%%)\n",zeros, perc_zeros);

  return 0;
}
