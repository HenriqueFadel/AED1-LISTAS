#include <stdio.h>

int main() {
    int i, nota, maior, menor, aprovados = 0, reprovados = 0;
    float soma = 0;

    printf("escreva a nota dos 10 alunos:");
    scanf("%d", &nota);
    maior = menor = nota;
    soma += nota;
    if (nota >= 60) {
        aprovados++;
    } else {
        reprovados++;
    }
    for (i = 1; i < 10; i++) {
        scanf("%d", &nota);
        soma += nota;
        if (nota > maior) {
            maior = nota;
        }
        if (nota < menor) {
            menor = nota;
        }
        if (nota >= 60) {
            aprovados++;
        } else {
            reprovados++;
        }
    }
    printf("A media eh: %f", soma / 10);
    printf("A maior eh: %d", maior);
    printf("A menor eh: %d", menor);
    printf("aprovados: %d",aprovados);
    printf("reprovados: %d", reprovados);

    return 0;
}
