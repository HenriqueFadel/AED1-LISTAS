int main() {
    int n, i;
    printf("Digite um n�mero positivo: ");
    scanf("%d", &n);
    if (n <= 1) {
        printf("N�mero inv�lido. Insira um n�mero maior que %d 1.\n");
        return 0;
    }
    printf("Os divisores de %d s�o: ", n);
    for (i = 2; i <= n; i++) {
        if (n % i == 0) {
            printf("%d ", i);
        }
    }
    printf("\nMostrando os divisores de %d.\n");
    return 0;
}
