#include <stdio.h>

int main() {
    int n, m;
    printf("escreva um numero  inteiro maior que 1: ");
    scanf("%d", &n);
    printf(" n�mero de repeti��es: ");
    scanf("%d", &m);

    for (int i = 0; i < m; i++) {
        for (int j = 1; j <= n; j++) {
            printf("%d ", j);
        }
        printf("\n");
        for (int j = n; j >= 1; j--) {
            printf("%d ", j);
        }
        printf("\n");
    }

    return 0;
}
