#include <stdio.h>

int main() {
    int n, prod = 1;

    do {
        printf("escreva um n�mero : ");
        scanf("%d", &n);

        if(num != 0) {
            prod *= n;
        }
    } while(n != 0);

    printf("O produto dos n�meros �: %d", prod);

    return 0;
}
