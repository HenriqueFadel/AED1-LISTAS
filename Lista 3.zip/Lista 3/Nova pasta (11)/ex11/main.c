#include <stdio.h>
#include <stdlib.h>

int main()
{
   int popa=5000000,popb=7000000,anos=0;
   while(popa<=popb){
    popa+=popa*0.03;
    popb+=popb*0.02;
    anos++;
   }
   printf("a popula��o vai ser igual em:%d",anos);
    return 0;
}
