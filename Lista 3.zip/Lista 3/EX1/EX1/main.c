#include <stdio.h>

int main() {
    int i = 1, j = 1;
    do {
        printf("\nTabuada do %d:\n", i);
        do {
            printf("%d + %d = %d\n", i, j, i + j);
            printf("%d - %d = %d\n", i, j, i - j);
            printf("%d * %d = %d\n", i, j, i * j);
            printf("%d / %d = %d\n", i, j, i / j);
            j++;
        } while (j <= 9);
        i++;
        j = 1;
    } while (i <= 9);
    return 0;
}
