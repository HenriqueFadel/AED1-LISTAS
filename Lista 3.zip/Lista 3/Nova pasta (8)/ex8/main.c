#include <stdio.h>

int main() {
    int n,sp = 0,si = 0;

    printf("Digite um numero inteiro positivo:");
    scanf("%d", &n);

    while(n <= 1000) {
        if(n % 2 == 0) {
            sp += n;
        } else {
            si += n;
        }

        printf("Digite  numero inteiro positivo");
        scanf("%d", &n);
    }

    printf("A soma dos numeros pares eh: %d\n", sp);
    printf("A soma dos numeros impares eh: %d\n", si);

    return 0;
}
