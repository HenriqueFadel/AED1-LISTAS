#include <stdio.h>

int main() {
    int n, i, anterior = 0, atual = 1, proximo;
    printf("Digite um numero para n: ");
    scanf("%d", &n);
    printf("uma sequencia com %d elementos: ", n);
    if (n == 1) {
        printf("%d", anterior);
    } else if (n >= 2) {
        printf("%d %d", anterior, atual);
        for (i = 3; i <= n; i++) {
            proximo = anterior + atual;
            printf(" %d", proximo);
            anterior = atual;
            atual = proximo;
        }
    }
    return 0;
}
