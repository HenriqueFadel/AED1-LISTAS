#include <stdio.h>

int main() {
    float compra, venda, lucro;
    int lucro1 = 0,lucro2 = 0, lucro3 = 0, total = 0;
    float total_compra = 0, total_venda = 0, total_lucro = 0;

    do {
        printf("escreva o preco de compra da mercadoria: ");
        scanf("%f", &compra);
        if (compra > 0) {
            printf("escreva o preco de venda da mercadoria: ");
            scanf("%f", &venda);
            if (venda > compra) {
                lucro = (venda - compra) / compra * 100;
                printf("Lucro da mercadoria: %.2f%%\n", lucro);
                if (lucro < 10) {
                    lucro1++;
                } else if (lucro >= 10 && lucro <= 20) {
                  lucro2++;
                } else {
                  lucro3++;
                }
                total++;
                total_compra += compra;
                total_venda += venda;
                total_lucro += venda - compra;
            } else {
                printf(" Tente novamente");
            }
        }
    } while (compra != 0);

    printf("Mercadorias com lucro inferior a 10%: %d\n", lucro1);
    printf("Mercadorias com lucro entre 10%% e 20%%: %d\n",lucro2);
    printf("Mercadorias com lucro superior a 20%%: %d\n", lucro3);
    printf("Total de mercadorias: %d\n",total);
    printf("Valor total de compra: %.2f\n", total_compra);
    printf("Valor total de venda: %.2f\n", total_venda);
    printf("Lucro total: %.2f\n", total_lucro);

    return 0;
}
