
   #include <stdio.h>

int main() {
    int n, pos = 0, neg = 0, zero = 0;

    do {
        printf("escreva um numero inteiro: ");
        scanf("%d", &n);

        if (n > 0)
            pos++;
        else if (n < 0)
            neg++;
        else if (n == 0)
            zero++;

    } while (n != -9999);

    printf(" valores positivos: %d\n", pos);
    printf(" valores negativos: %d\n", neg);
    printf("valores zeros: %d\n", zero);

    return 0;
}

