#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n=50,i=1;
    float soma=0;
while(i<=n){
    soma+=(float)(i*2-1)/i;
    i++;
} printf("soma: %f",soma);
    return 0;
}
#include <stdio.h>

