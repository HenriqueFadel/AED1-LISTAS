#include <stdio.h>

int main() {
    int op, pix_r = 0, pix_s = 0, saques = 0, depositos = 0;
    float saldo_inicial, valor, saldo_final;

    printf("escreva saldo inicial : ");
    scanf("%f", &saldo_inicial);

    saldo_final = saldo_inicial;

    do {
        printf("escreva a opera��o:");
        printf("1. Dep�sito em dinheiro
                2. Retirada em dinheiro
                3. Recebimento em PIX
                4. Transfer�ncia em PIX
                5. Fim\n");
        scanf("%d", &op);

        if (op == 5) {
            break;
        }

        printf("escreva o valor: ");
        scanf("%f", &valor);

        if (op == 1) {
            saldo_final += valor;
            depositos++;
        } else if (op == 2) {
            saldo_final -= valor;
            saques++;
        } else if (op == 3) {
            saldo_final += valor;
            pix_r++;
        } else if (op == 4) {
            saldo_final -= valor;
            pix_s++;
        } else {
            printf("Opera��o inv�lida!\n");
        }

    } while (op != 5);

    printf("Saldo final %f", saldo_final);

    if (saldo_final == 0) {
        printf("CONTA ZERADA\n");
    } else if (saldo_final < 0) {
        printf("CONTA ESTOURADA\n");
    } else {
        printf("CONTA PREFERENCIAL\n");
    }

    printf(" PIX recebidos: %d", pix_r);
    printf(" PIX enviados: %d", pix_s);
    printf(" saques: %d", saques);
    printf("dep�sitos em dinheiro: %d", depositos);

    return 0;
}
