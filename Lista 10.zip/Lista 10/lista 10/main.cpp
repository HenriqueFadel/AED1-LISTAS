#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

using namespace std;

class Data {
public:
    int dia;
    int mes;
    int ano;
    int hora;
    int minuto;

    Data() {
        time_t now = time(0);
        tm *ltm = localtime(&now);

        dia = ltm->tm_mday;
        mes = ltm->tm_mon + 1;
        ano = ltm->tm_year + 1900;
        hora = ltm->tm_hour;
        minuto = ltm->tm_min;
    }

    void exibir() const {
        cout << dia << "/" << mes << "/" << ano << " " << hora << ":" << minuto;
    }
};

class Client {
public:
    string cpf;
    string nome;
    Data dataCadastro;

    Client() {}

    Client(string cpf, string nome) {
        this->cpf = cpf;
        this->nome = nome;
    }

    void exibir() const {
        cout << "CPF: " << cpf << endl;
        cout << "Nome: " << nome << endl;
        cout << "Data de cadastro: ";
        dataCadastro.exibir();
        cout << endl;
    }
};

class Veiculo {
public:
    int cod;
    string placa;
    string modelo;
    Data entrada;
    Data saida;
    float valorPago;
    Client cliente;

    static int proximoCodigo;

    Veiculo() {
        cod = proximoCodigo++;
        valorPago = 0.0;
    }

    void re() {
        cout << "Placa: ";
        cin >> placa;
        cout << "Modelo: ";
        cin.ignore();
        getline(cin, modelo);
        cout << "o cliente esta cadastrado? (s/n): ";
        char opcao;
        cin >> opcao;
        if (opcao == 's') {
            string cpf, nome;
            cout << "CPF: ";
            cin >> cpf;
            cout << "Nome: ";
            cin.ignore();
            getline(cin, nome);
            cliente = Client(cpf, nome);
            ad();
        }
        cout << "registrado!!" << endl;
    }

    void rs() {
        cout << "Placa: ";
        string placaPesquisa;
        cin >> placaPesquisa;
        if (placa == placaPesquisa) {
            saida = Data();
            cal();
            cout << "Saida com sucesso!!." << endl;
        } else {
            cout << " n�o encontrado." << endl;
        }
    }

    void exibir() const {
        cout << "Codigo: " << cod << endl;
        cout << "Placa: " << placa << endl;
        cout << "Modelo: " << modelo << endl;
        cout << "Entrada: ";
        entrada.exibir();
        cout << endl;
        if (saida.dia != 0) {
            cout << "Saida: ";
            saida.exibir();
            cout << endl;
            cout << "Valor pago: R$" << valorPago << endl;
        } else {
            cout << " n�o saiu do estacionamento." << endl;
        }
        if (!cliente.cpf.empty()) {
            cout << "Cliente:" << endl;
            cliente.exibir();
        }
    }

    void ad() {
        valorPago -= 10.0;
        if (valorPago < 0.0) {
            valorPago = 0.0;
        }
    }

    void cal() {
        int minutosEstacionado = (saida.hora * 60 + saida.minuto) - (entrada.hora * 60 + entrada.minuto);
        valorPago = minutosEstacionado * 0.05;
    }
};

int Veiculo::proximoCodigo = 1;

vector<Veiculo> veiculos;

void exibirMenu() {
    cout << " menu abaixo" << endl;
    cout << "1. cadastro cliente" << endl;
    cout << "2. busque veiculo" << endl;
    cout << "3. Atualize um veiculo" << endl;
    cout << "4. registre entrada e veiculo" << endl;
    cout << "5. registre saida do veiculo" << endl;
    cout << "6.  arquivo de veiculos" << endl;
    cout << "7.  arquivo de valor total" << endl;
    cout << "0. saindo" << endl;

}

void ic() {
    string cpf, nome;
    cout << "CPF: ";
    cin >> cpf;
    cout << "Nome: ";
    cin.ignore();
    getline(cin, nome);
    Client cliente(cpf, nome);
    cout << "Cadastrado com sucesso." << endl;
}

void pv() {
    cout << "escreva o codigo ou placa do veiculo: ";
    string pesquisa;
    cin.ignore();
    getline(cin, pesquisa);
    bool encontrado = false;
    for (const auto& veiculo : veiculos) {
        if (to_string(veiculo.cod) == pesquisa ||
            veiculo.placa == pesquisa) {
            veiculo.exibir();
            encontrado = true;
        }
    }
    if (!encontrado) {
        cout << "nao encontrado." << endl;
    }
}

void av() {
    cout << "escrevao codigo ou placa do veiculo: ";
    string pesquisa;
    cin.ignore();
    getline(cin, pesquisa);
    bool encontrado = false;
    for (auto& veiculo : veiculos) {
        if (to_string(veiculo.cod) == pesquisa ||
            veiculo.placa == pesquisa) {
            veiculo.exibir();
            cout << "Digite a nova placa: ";
            cin >> veiculo.placa;
            cout << "Digite o novo modelo: ";
            cin.ignore();
            getline(cin, veiculo.modelo);
            cout << " atualizado." << endl;
            encontrado = true;
        }
    }
    if (!encontrado) {
        cout << " nao encontrado." << endl;
    }
}

void re() {
    string placa, modelo;
    cout << "Placa: ";
    cin >> placa;
    cout << "Modelo: ";
    cin.ignore();
    getline(cin, modelo);
    Veiculo veiculo;
    veiculo.placa = placa;
    veiculo.modelo = modelo;
    veiculo.re();
    veiculos.push_back(veiculo);
    cout << "Entrada registrada." << endl;
}

void rs() {
    cout << "escreva a placa do veiculo: ";
    string placaPesquisa;
    cin.ignore();
    getline(cin, placaPesquisa);
    bool encontrado = false;
    for (auto& veiculo : veiculos) {
        if (veiculo.placa == placaPesquisa) {
            veiculo.rs();
            encontrado = true;
        }
    }
    if (!encontrado) {
        cout << " n�o encontrado." << endl;
    }
}

void gv() {
    ofstream arquivo("veiculos.txt");
    if (arquivo.is_open()) {
        for (const auto& veiculo : veiculos) {
            arquivo << "C�digo: " << veiculo.cod << endl;
            arquivo << "Placa: " << veiculo.placa << endl;
            arquivo << "Modelo: " << veiculo.modelo << endl;
            arquivo << "Entrada: ";
            veiculo.entrada.exibir();
            arquivo << endl;
            if (veiculo.saida.dia != 0) {
                arquivo << "Sa�da: ";
                veiculo.saida.exibir();
                arquivo << endl;
                arquivo << "Valor pago: R$" << veiculo.valorPago << endl;
            } else {
                arquivo << "Ve�culo ainda n�o saiu do estacionamento." << endl;
            }
            if (!veiculo.cliente.cpf.empty()) {
                arquivo << "Cliente:" << endl;
                arquivo << "CPF: " << veiculo.cliente.cpf << endl;
                arquivo << "Nome: " << veiculo.cliente.nome << endl;
                arquivo << "Data de cadastro: ";
                veiculo.cliente.dataCadastro.exibir();
                arquivo << endl;
            }
            arquivo << "======================" << endl;
        }
        arquivo.close();
        cout << "Arquivo veiculos.txt gerado." << endl;
    } else {
        cout << "Erro " << endl;
    }
}

void gt() {
    float valorTotal = 0.0;
    for (const auto& veiculo : veiculos) {
        valorTotal += veiculo.valorPago;
    }
    ofstream arquivo("valor_total.txt");
    if (arquivo.is_open()) {
        arquivo << "Valor total arrecadado: R$" << valorTotal << endl;
        arquivo.close();
        cout << "Arquivo valor_total.txt gerado." << endl;
    } else {
        cout << "Erro ao abrir o arquivo." << endl;
    }
}

int main() {
    int opcao;
    do {
        exibirMenu();
        cout << "selecione um numero: ";
        cin >> opcao;
        switch (opcao) {
            case 1:
                ic();
                break;
            case 2:
                pv();
                break;
            case 3:
                av();
                break;
            case 4:
                re();
                break;
            case 5:
                rs();
                break;
            case 6:
                gv();
                break;
            case 7:
                gt();
                break;
            case 0:
                cout << "saindo" << endl;
                break;
            default:
                cout << "erro." << endl;
                break;
        }
        cout << endl;
    } while (opcao != 0);

    return 0;
}
