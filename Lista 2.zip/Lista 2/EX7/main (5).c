#include <stdio.h>
#include <stdlib.h>

int main()
{
    char car;
    printf("digite um caracter:");
    scanf("%c",&car);
    if (car>='A' && car<='Z'){
        printf("� maiuscula %c");
    }
    else if (car>='a' && car<='z'){
    printf("� minuscula %c");
    }
    else if(car>'0' && car<'9'){
    printf("� um numero entre 0 e 9 %c");
    }
    return 0;
}
