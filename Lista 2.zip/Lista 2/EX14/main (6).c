#include <stdio.h>
#include <stdio.h>

int main() {
    int quantidade;
    float preco_unitario = 0.50, valor_total;

    printf("Informe a quantidade de parafusos desejada:\n");
    scanf("%d", &quantidade);

    if (quantidade <= 0) {
        printf("Quantidade invalida.\n");
    } else {
        if (quantidade <= 100) {
            valor_total = quantidade * preco_unitario;
        } else if (quantidade <= 200) {
            valor_total = quantidade * preco_unitario * 0.9;
        } else if (quantidade <= 300) {
            valor_total = quantidade * preco_unitario * 0.8;
        } else if (quantidade <= 400) {
            valor_total = quantidade * preco_unitario * 0.7;
        } else {
            valor_total = quantidade * preco_unitario * 0.6;
        }

        printf("Valor total da compra: R$ %.2f\n", valor_total);
    }

    return 0;
}
