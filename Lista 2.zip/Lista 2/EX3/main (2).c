#include <stdio.h>

#include <stdio.h>

int main() {
  int dia, mes, ano;
  
  printf("Digite a data no formato dd/mm/aaaa: ");
  scanf("%d/%d/%d", &dia, &mes, &ano);
  
  if (ano != 2022) {
    printf("Data inválida. Ano diferente de 2022.\n");
    return 0;
  }
  
  if (mes < 1 || mes > 12) {
    printf("Data inválida. Mês deve estar entre 1 e 12.\n");
    return 0;
  }
  
  if (dia >= 1 && dia <= 31) {
    printf("Data válida.\n");
  } else {
    printf("Data inválida. Dia deve estar entre 1 e 31.\n");
  }
  
  return 0;
}
