#include <stdio.h>
#include <stdlib.h>

int main() {
    float x1, y1, x2, y2, distancia;

    printf("Entre com as coordenadas do ponto P1 (x1, y1):\n");
    scanf("%f %f", &x1, &y1);

    printf("Entre com as coordenadas do ponto P2 (x2, y2):\n");
    scanf("%f %f", &x2, &y2);

    if (x1 == x2 && y1 == y2) {
        printf("Os pontos informados sao iguais.\n");
    } else {
        distancia = (x1 - x2) + (y1 - y2);
        printf("A distancia de Manhattan entre os pontos P1 e P2 eh: %f\n", distancia);
    }

    return 0;
}
