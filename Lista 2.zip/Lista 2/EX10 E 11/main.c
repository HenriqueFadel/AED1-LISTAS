#include <stdio.h>
#include <stdlib.h>


int main() {
    int operacao;
    float a, b, resultado;

    printf("Selecione a operacao desejada:\n");
    printf("1 - Soma\n");
    printf("2 - Subtracao\n");
    printf("3 - Multiplicacao\n");
    printf("4 - Divisao\n");
    scanf("%d", &operacao);

    printf("Digite o primeiro operando: ");
    scanf("%f", &a);

    printf("Digite o segundo operando: ");
    scanf("%f", &b);

    switch (operacao) {
        case 1:
            resultado = a + b;
            printf("Resultado da soma: %.2f\n", resultado);
            break;
        case 2:
            resultado = a - b;
            printf("Resultado da subtracao: %.2f\n", resultado);
            break;
        case 3:
            resultado = a * b;
            printf("Resultado da multiplicacao: %.2f\n", resultado);
            break;
        case 4:
            if (b == 0) {
                printf("Erro: divisao por zero.\n");
            } else {
                resultado = a / b;
                printf("Resultado da divisao: %.2f\n", resultado);
            }
            break;
        default:
            printf("Operacao invalida.\n");
            break;
    }

    return 0;
}

