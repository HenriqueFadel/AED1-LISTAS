#include <stdio.h>
#include <stdlib.h>

int main()
{
    float altura,peso,imc;

    printf("digite altura em metro:");

    scanf("%f",&altura);

    printf("digite peso em kg:");

    scanf("%f",&peso);

    imc = peso / (altura * altura);

    printf("o imc �: %f",imc);

    if (imc < 18.5){
    printf("abaixo do peso");
    }if(imc>18.5 && imc<24.9){
    printf("peso ideal PARABENS ");
    }else if(imc>25 && imc<29.9){
    printf("levemente acima do peso");}
    else{
    printf("obesidade");
    }
    return 0;
}

