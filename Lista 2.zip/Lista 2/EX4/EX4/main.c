#include <stdio.h>

int main() {
  int num1, num2, num3;

  printf("Digite tr�s n�meros: ");
  scanf("%d %d %d", &num1, &num2, &num3);

  // verifica o maior n�mero
  int maior = num1;
  if (num2 > maior) {
    maior = num2;
  }
  if (num3 > maior) {
    maior = num3;
  }

  // verifica o menor n�mero
  int menor = num1;
  if (num2 < menor) {
    menor = num2;
  }
  if (num3 < menor) {
    menor = num3;
  }

  // verifica o elemento do meio
  int meio;
  if ((num1 >= num2 && num1 <= num3) || (num1 <= num2 && num1 >= num3)) {
    meio = num1;
  } else if ((num2 >= num1 && num2 <= num3) || (num2 <= num1 && num2 >= num3)) {
    meio = num2;
  } else {
    meio = num3;
  }

  printf("Maior: %d\n", maior);
  printf("Menor: %d\n", menor);
  printf("Elemento do meio: %d\n", meio);

  return 0;
}
