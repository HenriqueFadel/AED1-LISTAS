#include <stdio.h>
#include <math.h>

int main() {
    float numero, parte_inteira, parte_fracionaria;

    printf("Digite um numero real: ");
    scanf("%f", &numero);

    parte_inteira = floor(numero);
    parte_fracionaria = numero - parte_inteira;

    printf("Parte inteira: %.0f\n", parte_inteira);
    printf("Parte fracionaria: %.2f\n", parte_fracionaria);

    return 0;
}
