#include <stdio.h>

int main() {
  int num;
  printf("digite um numero");
  scanf("%d",&num);
  if (num%2==0)
    printf("esse numero e par %d");
  else{
    printf("esse numero e impar");
  }
  if (num<=0)
    printf("o numero não pode ser menor ou igual a zero");
  else{
    printf("ok");
  }
  return 0;
}