#include <stdio.h>

int main() {
  int num;
  printf("digite o valor de um número:");
  scanf("%d",&num);
  if (num>0){
    printf("1%d");
  }
  else{
    if (num<0){
      printf("-1%d");
    }
  }
  if (num==0){
    printf("0%d");
  }
  
  return 0;
}