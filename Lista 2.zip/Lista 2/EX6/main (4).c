#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x,y;
    printf("digite o valor de x e y:");
    scanf("%d%d",&x,&y);
    if (x !=0 && y!=0){
        if (x>0 && y>0)
            printf("primeiro quadrante %d");
        else if (x<0 && y>0)
          printf("segundo quadrante %d");
        else if(x<0 && y<0)
              printf("terceiro quadrante %d");
        else
         printf("quarto quadrante %d");
    }
    return 0;
}
