#include <stdio.h>

int main() {
  int senha;
  printf("digite a senha");
  scanf("%d",&senha);
  if (senha!=1234)
    printf("acesso negado %d");
  else{
    printf("acesso permitido %d");
  }
  return 0;
}