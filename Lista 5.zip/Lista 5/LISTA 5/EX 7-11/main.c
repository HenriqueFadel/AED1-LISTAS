#include <stdio.h>
#include <stdlib.h>

/* Defini��o das fun��es/procedimentos */

/*
Descri��o: descrever o objetivo do procedimento/fun��o
Par�metros (entradas): indicar os par�metros e seus tipos
Retorno (sa�da): indicar o tipo de retorno
*/

int k_esimo_digito(int n, int k) {
    // implementa��o da fun��o k_esimo_digito
}

void imprimir_numeros(int limite_inferior, int limite_superior, int incremento) {
    //  procedimento imprimir_numeros
}

float somatorio(int n) {
    //  fun��o calcular somatorio
}

int manhattan(int x1, int y1, int x2, int y2) {
    //  fun��o calcular distancia manhattan
}

float delta(float a, float b, float c) {
    //  fun��o calcular delta
}

/* Fun��o principal que cont�m o menu */
int main() {
    int opcao, n, k, n1, n2, incremento;
    float a, b, c;

    do {
        // exibi��o do menu
        printf("\n\nMENU\n");
        printf("1 - k-esimo digito de um numero\n");
        printf("2 - imprimir numeros entre limites\n");
        printf("3 - calcular somatorio\n");
        printf("4 - calcular distancia Manhattan\n");
        printf("5 - calcular delta\n");
        printf("0 - sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch(opcao) {
            case 1:
                printf("ESCREVA o numero: ");
                scanf("%d", &n);
                printf("ESCREVA o k: ");
                scanf("%d", &k);
                printf("O k-esimo digito de %d eh: %d\n", n, k_esimo_digito(n, k));
                break;
            case 2:
                printf("ESCREVA o limite inferior: ");
                scanf("%d", &n1);
                printf("ESCREVA o limite superior: ");
                scanf("%d", &n2);
                printf("ESCREVA o valor do incremento: ");
                scanf("%d", &incremento);
                imprimir_numeros(n1, n2, incremento);
                break;
            case 3:
                printf("ESCREVA o valor de n: ");
                scanf("%d", &n);
                printf("O somatorio eh: %f\n", somatorio(n));
                break;
            case 4:
                printf("ESCREVA as coordenadas do ponto 1 (x y): ");
                scanf("%d %d", &n1, &n2);
                printf("ESCREVA as coordenadas do ponto 2 (x y): ");
                scanf("%d %d", &k, &incremento);
                printf("A distancia Manhattan entre os pontos eh: %d\n",manhattan(n1, n2, k, incremento));
                break;
            case 5:
                printf("ESCREVA os coeficientes da equacao (a b c): ");
                scanf("%f %f %f", &a, &b, &c);
                printf("O delta eh: %f\n", delta(a, b, c));
                break;
            case 0:
                printf("SAIR\n");
                break;
            default:
                printf("ERROOO. TENTE DNV");
                   }
    }while (opcao != 5);

    return 0;
}
