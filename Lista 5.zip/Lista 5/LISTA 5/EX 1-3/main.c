
/*
Descri��o: Fun��o recebera um n�mero como par�metro e vai calcular o valor do cubo desse n�mero.
Par�metros (entradas):
  - num (int): n�mero inteiro .
Retorno (sa�da):
  - int: valor do cubo .
*/
int Cubo(int num) {
  return num*num*num;
}
/*
Descri��o: Fun��o que calcula a m�dia de 5 numeros.
Par�metros (entradas):
  - num1 (float): primeiro n�mero.
  - num2 (float): segundo n�mero.
  - num3 (float): terceiro n�mero.
  - num4 (float): quarto n�mero.
Retorno (sa�da):
  - float: valor da m�dia aritm�tica .
*/
float Media(float num1, float num2, float num3, float num4, float num5) {
  float soma = num1 + num2 + num3 + num4 + num5;
  return soma / 5;
}
/*
Descri��o:vai recebe um n�mero e ir� imprimir todos os n�meros primos ATE esse n�mero.
Par�metros (entradas):
  - n (int): n�mero inteiro.
Retorno (sa�da): n tem.
*/
void NumerosPrimos(int n) {
  int i, j, primo;
  for(i = 2; i <= n; i++) {
    primo = 1;
    for(j = 2; j <= i/2; j++) {
      if(i % j == 0) {
        primo = 0;
        break;
      }
    }
    if(primo == 1) {
      printf("%d ", i);
    }
  }
}
#include <stdio.h>

int main() {
  int opcao;

  do {
    printf("digite opcao:\n");
    printf("1-Calcular cubo de um numero\n");
    printf("2-Calcular media de cinco numeros\n");
    printf("3-Imprimir numeros primos ate um numero n\n");
    printf("0-Sair\n");

    scanf("%d", &opcao);

    switch(opcao) {
      case 1: {
        int num;
        printf("escreva um numero: ");
        scanf("%d", &num);
        printf("Cubo%d sera: %d\n", num,Cubo(num));
        break;
      }
      case 2: {
        float num1, num2, num3, num4, num5;
        printf("escreva cinco numeros: ");
        scanf("%f %f %f %f %f", &num1, &num2, &num3, &num4, &num5);
        printf("Media: %.2f\n", Media(num1, num2, num3, num4, num5));
        break;
      }
      case 3: {
        int n;
        printf("escreva um numero: ");
        scanf("%d", &n);
        printf("Numeros primos ate %d: ", n);
        NumerosPrimos(n);
        printf("\n");
        break;
      }
      case 0: {
        printf("SAIR\n");
        break;
      }
      default: {
        printf("ERRO.TENTE DNV\n");
        break;
      }
    }

  } while(opcao != 0);

  return 0;
}
