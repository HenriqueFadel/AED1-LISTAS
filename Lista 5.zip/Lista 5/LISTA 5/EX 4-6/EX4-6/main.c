#include <stdio.h>
#include <stdlib.h>

void encontrarMaxMin(int nums[], int tam, int* max, int* min);
float calcularDiametro(float raio);
float calcularCircunferencia(float raio);
float calcularArea(float raio);
int operacaoBooleana(int A, int B, int C);

int main() {
    int opcao = 0;
    int nums[100], tam, max, min;
    float raio;

    while (opcao != 5) {
        printf("MENU:\n");
        printf("1 - Encontrar o m�ximo e o m�nimo de n�meros\n");
        printf("2 - Calcular o di�metro de uma circunfer�ncia\n");
        printf("3 - Calcular a circunfer�ncia de uma circunfer�ncia\n");
        printf("4 - Calcular a �rea de um c�rculo\n");
        printf("5 - Sair \n");
        printf("ESCREVA a op��o desejada: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("ESCREVA o tamanho do vetor: ");
                scanf("%d", &tam);

                printf("ESCREVA os valores do vetor:\n");
                for (int i = 0; i < tam; i++) {
                    scanf("%d", &nums[i]);
                }

                encontrarMaxMin(nums, tam, &max, &min);
                printf("O valor m�ximo � %d e o valor m�nimo � %d\n", max, min);
                break;

            case 2:
                printf("ESCREVA o valor do raio: ");
                scanf("%f", &raio);

                printf("O di�metro da circunfer�ncia � %f\n", calcularDiametro(raio));
                break;

            case 3:
                printf("ESCREVA o valor do raio: ");
                scanf("%f", &raio);

                printf("A circunfer�ncia da circunfer�ncia � %f\n", calcularCircunferencia(raio));
                break;

            case 4:
                printf("ESCREVAo valor do raio: ");
                scanf("%f", &raio);

                printf("A �rea do c�rculo � %f\n", calcularArea(raio));
                break;

            case 5:
                printf("Encerrando o programa...\n");
                break;

            default:
                printf("Op��o inv�lida, tente novamente.\n");
        }
    }

    return 0;
}

void encontrarMaxMin(int nums[], int tam, int* max, int* min) {
    *max = nums[0];
    *min = nums[0];

    for (int i = 1; i < tam; i++) {
        if (nums[i] > *max) {
            *max = nums[i];
        }

        if (nums[i] < *min) {
            *min = nums[i];
        }
    }
}

float calcularDiametro(float raio) {
    return raio * 2;
}

float calcularCircunferencia(float raio) {
    return 2 * 3.14 * raio;
}

float calcularArea(float raio) {
    return 3.14 * raio * raio;
}

int operacaoBooleana(int A, int B, int C) {
    return !A || B && C;
}
