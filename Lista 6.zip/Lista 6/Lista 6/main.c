#include <stdio.h>


void maiorMenor(int a, int b, int c, int* maior, int* menor);
void operacaoBooleana(int A, int B, int C, int* resultado);
float mediaMaior(int num1, int num2, int num3, int* maior);
void imprimirVariaveis(int a, int b, int c);
void lerVetor(int vetor[], int tam);
void mostrarVetor(int vetor[], int tam);
void exibe_info_tipos();
int divisores(int n, int *max, int *min);

int main() {
    int opcao;
    int num1, num2, num3;
    int maior, menor, resultado;
    float media;
    int vetor[3];
    int n, max, min;

    do {
        printf("\nSelecione uma opcao:\n");
        printf("1 - Calcular o maior e o menor de tres numeros\n");
        printf("2 - Realizar operacao booleana\n");
        printf("3 - Calcular a media e o maior de tres numeros\n");
        printf("4 - Imprimir variaveis\n");
        printf("5 - ler vetores\n");
        printf("6 - mostrar vetores\n");
        printf("7 - exibir tipos\n");
        printf("8-  primo\n");
        printf("0 - Sair\n");

        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("\nDigite tres numeros: ");
                scanf("%d %d %d", &num1, &num2, &num3);
                maiorMenor(num1, num2, num3, &maior, &menor);
                printf("O maior numero e: %d\n", maior);
                printf("O menor numero e: %d\n", menor);
                break;
            case 2:
                printf("\nDigite tres valores booleanos (0 ou 1): ");
                scanf("%d %d %d", &num1, &num2, &num3);
                operacaoBooleana(num1, num2, num3, &resultado);
                printf("Resultado da operacao: %d\n", resultado);
                break;
            case 3:
                printf("\nDigite tres numeros: ");
                scanf("%d %d %d", &num1, &num2, &num3);
                media = mediaMaior(num1, num2, num3, &maior);
                printf("A media dos numeros e: %.2f\n", media);
                printf("O maior numero e: %d\n", maior);
                break;
            case 4:
                printf("\nDigite tres numeros: ");
                scanf("%d %d %d", &num1, &num2, &num3);
                imprimirVariaveis(num1, num2, num3);
                break;
            case 5:
                lerVetor(vetor, 3);
                break;
            case 6:
               mostrarVetor(vetor, 3);
                break;
            case 7:
              exibe_info_tipos();
                break;
            case 8:
                printf("\nDigite um numero inteiro: ");
                scanf("%d", &n);
                resultado = divisores(n, &max, &min);
                if (resultado == 0) {
                    printf("%d nao tem divisores proprios\n", n);
                } else {
                    printf("Os maiores e menores divisores proprios de %d sao %d e %d, respectivamente\n", n, max, min);
                }
                break;
                break;
            case 0:
                printf("\nSaindo do programa...\n");
                break;
            default:
                printf("\nOpcao invalida, tente novamente.\n");
        }
    } while (opcao != 0);

    return 0;
}

/*
Descrição: procedimento que recebe três números por parâmetro e “retorne” por referência o maior e menor
Entradas: três números inteiros (a, b, c)
Saída: por referência, o maior e o menor dos três números
*/
void maiorMenor(int a, int b, int c, int* maior, int* menor) {
    if (a >= b && a >= c) {
        *maior = a;
        if (b <= c) {
            *menor = b;
        } else {
            *menor = c;
        }
    } else if (b >= a && b >= c) {
        *maior = b;
        if (a <= c) {
            *menor = a;
        } else {
            *menor = c;
        }
    } else {
        *maior = c;
        if (a < b) {
            *menor = a; }

        else if (b <= a && b <= c) {
        *menor = b;
    } else {
        *menor = c;
    }
}
}
/*
Descrição: Este procedimento recebe três valores booleanos (A, B e C) por referência e retorna por referência o valor booleano da operação ⌐ (A v ⌐ B ^ C).
Entradas:
- a (ponteiro para int): ponteiro que aponta para o valor de A.
- b (ponteiro para int): ponteiro que aponta para o valor de B.
- c (ponteiro para int): ponteiro que aponta para o valor de C.
- resultado (ponteiro para int): ponteiro que aponta para a variável que irá armazenar o resultado da operação.
Saída:
- Não há retorno. O resultado é armazenado na variável apontada pelo ponteiro "resultado".
*/
void operacaoBooleana(int a, int b, int c, int *resultado) {
    *resultado = !(a || !(b ^ c));
}
/*
Descrição: Essa função calcula a média de três números inteiros e determina o maior número entre eles.
Entradas:

a (int): primeiro número inteiro
b (int): segundo número inteiro
c (int): terceiro número inteiro
*maior (ponteiro para int): ponteiro que será usado para armazenar o maior número entre a, b e c
Saída:
media (float): média dos três números a, b e c
*/
float mediaMaior(int a, int b, int c, int *maior) {
    float media = (a + b + c) / 3.0;

    if (a >= b && a >= c) {
        *maior = a;
    } else if (b >= a && b >= c) {
        *maior = b;
    } else {
        *maior = c;
    }

    return media;
}
/*
Descrição: Procedimento que lê três valores inteiros (a, b, c) e mostra na tela o nome da variável,
            o endereço e o valor da variável.
Entradas: três valores inteiros a, b, c
Saída: não possui retorno, apenas imprime os valores na tela
*/
void imprimirVariaveis(int a, int b, int c) {
    printf("NOME_VARIAVEL\tENDERECO\tVALOR\n");
    printf("a\t\t%p\t%d\n", &a, a);
    printf("b\t\t%p\t%d\n", &b, b);
    printf("c\t\t%p\t%d\n", &c, c);
}
void lerVetor(int vetor[], int tam) {
    int i;
    printf("Digite %d valores inteiros:\n", tam);
    for (i = 0; i < tam; i++) {
        printf("Digite o valor da posicao %d: ", i);
        scanf("%d", &vetor[i]);
    }
}
void mostrarVetor(int vetor[], int tam) {
    int i;
    printf("POSICAO_VETOR\tENDERECO\t\tVALOR\n");
    for (i = 0; i < tam; i++) {
        printf("%d\t\t%p\t%d\n", i, &vetor[i], vetor[i]);
    }
}
/*
Descrição: Função que exibe informações sobre tipos de dados
Entradas: nenhuma
Saída: nenhuma
*/
void exibe_info_tipos() {
    char c;
    int i;
    float f;
    double d;
    int *pi;
    char *pc;
    int *pi2;
    float *pf;
    double *pd;

    /* Exibe as informações sobre os tipos de dados */
    printf("\n");
    printf("char: endereco=%p, tamanho=%d\n", (void *)&c, (int)sizeof(char));
    printf("int: endereco=%p, tamanho=%d\n", (void *)&i, (int)sizeof(int));
    printf("float: endereco=%p, tamanho=%d\n", (void *)&f, (int)sizeof(float));
    printf("double: endereco=%p, tamanho=%d\n", (void *)&d, (int)sizeof(double));
    printf("int *: endereco=%p, tamanho=%d\n", (void *)&pi, (int)sizeof(int *));
    printf("char *: endereco=%p, tamanho=%d\n", (void *)&pc, (int)sizeof(char *));
    printf("int *: endereco=%p, tamanho=%d\n", (void *)&pi2, (int)sizeof(int *));
    printf("float *: endereco=%p, tamanho=%d\n", (void *)&pf, (int)sizeof(float *));
    printf("double *: endereco=%p, tamanho=%d\n", (void *)&pd, (int)sizeof(double *));
}
/*
Descrição: função que recebe um número inteiro n e dois números inteiros max e min por referência e retorna (0) se n é primo e (1) caso contrário
Entradas: um valor inteiro a ser verificado (n) e dois números inteiros por referência (max e min)
Saída: um valor inteiro (0 ou 1)
*/
int divisores(int n, int *max, int *min) {
    int i, flag = 0;
    *max = *min = 0;

    for (i = 2; i <= n/2; ++i) {
        if (n % i == 0) {
            if (*min == 0) {
                *min = i;
            }
            *max = i;
            flag = 1;
        }
    }

    if (flag == 0) {
        return 0;
    } else {
        return 1;
    }
}


